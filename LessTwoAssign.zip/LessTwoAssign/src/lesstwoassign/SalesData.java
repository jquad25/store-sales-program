/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lesstwoassign;

/**
 *
 * @author ujordanaquadro
 */

import java.util.Scanner;
import java.util.Arrays;
import java.lang.Math;
import static java.lang.System.in;
import java.util.Locale;

public class SalesData {
    
  private String dayOfWeek;
  private double saleAmount;
  
  public SalesData(String sDay, double sAmnt)
  {
      dayOfWeek = sDay;
      saleAmount = sAmnt;
  }
  
  public String toString()
  {
      return dayOfWeek + saleAmount;
  }
    
}
