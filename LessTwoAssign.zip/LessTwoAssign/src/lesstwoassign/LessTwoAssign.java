/*
 * This program allows a user to enter the amount of a sale
 * and the day of a sale and store the information.
 */
package lesstwoassign;

/**
 *
 * @author ujordanaquadro v1.0
 */

import java.util.Scanner;
import java.util.Arrays;
import java.lang.Math;
import static java.lang.System.in;
import java.util.Locale;

public class LessTwoAssign {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
     //add notes to all classes      
        SalesEntry se = new SalesEntry();
        String inputDay = "";
        double inputAmount = 0.0;
        boolean programRun = true;
        
        Scanner in = new Scanner(System.in);

        while(programRun)
        {
            
            System.out.println("Enter the day of the week. Enter \"Q\" "
                        + "to quit.  \n");
            
            if(in.hasNext("Q"))
            {
                System.exit(0);
            }
 /*TRY ADDING DAYS OF WEEK INTO () OF BELOW hasNEXT
            FOR EX ("Monday", "Tuesday", "Wednesday" etc.
            otherwise the error message would never trigger
            unless they enter something other than a string
            
            if(in.hasNext("Monday" "Tuesday" "Wednesday" "Thursday" "Friday"
            "Saturday" "Sunday")
            {
                inputDay = in.next().toUpperCase();
            }
            
            */
         
            else if(in.hasNext())
            {
                    inputDay = in.next().toUpperCase();
            }
      
            else
            {
                System.out.println("That was not a valid entry. " 
                    + "Please try again or hit Q to quit. \n");
            } 
            
            System.out.println("Enter the amount of the sale " +
                    "(ex. 48.99): \n");
            if(in.hasNextDouble()) 
            {
                inputAmount = in.nextDouble();
            }
            
            /*
            if(in.hasNext("S")
            {
                some code to show highest sale and corresponding day
            }
            */
        
            else
            {
                System.out.println("That was not a valid amount. " +
                    "Please enter a valid amount " +
                    "(ex. 7.02). "); 
            }
            
            se.addSalesData(new SalesData(inputDay, inputAmount)); 
        }

 
        
    }
    // add S option to submit and get results
    //how are you going to get results show here?
    
}
