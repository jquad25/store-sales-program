/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lesstwoassign;

/**
 *
 * @author ujordanaquadro
 */


import java.util.Scanner;
import java.util.Arrays;
import java.lang.Math;
import static java.lang.System.in;
import java.util.Locale;

public class SalesEntry {
    
private SalesData[] entry;
private int numberOfEntries;

public SalesEntry()
{
    entry = new SalesData[7];
    numberOfEntries = 0;  
}

public SalesEntry(int arraySize)
{
    entry = new SalesData[arraySize];
    numberOfEntries = 0;
}
  
public void addSalesData(SalesData salesData)
{
    if(numberOfEntries < entry.length)
    {
        entry[numberOfEntries] = salesData;
        numberOfEntries++;
    }
}

public String toString()
{
    String saleSummary = "The week's sales are:  ";
    
    for(int i = 0; i < numberOfEntries; i++)
    {
        saleSummary = saleSummary + entry[i].toString() + "\n";
    }
    
    return saleSummary;
}
    
    
}
